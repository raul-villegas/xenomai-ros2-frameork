#include <stdio.h>

#include <unistd.h>

#include <iterator>

#include <signal.h>

#include <vector>

#include <sys/syscall.h>



#include "framework/multiCommClass.h"

#include "framework/runnableClass.h"

#include "framework/superThread.h"

#include "framework/icoCommClass.h"

#include "ControllerPan/ControllerPan.h"

// #include <Your 20-sim-code-generated h-file?> Don't forget to compile the cpp file by adding it to CMakeLists.txt



volatile bool exitbool = false;



void exit_handler(int s)

{

    printf("Caught signal %d\n", s);

    exitbool = true;

}

void ReadConvert(const double* src, double *dst)

{

static double lastKnownGoodValue = 0;

dst[0] = (src[0]-32.0) / 1.8; // scaling

if ( src[1]!=0) // filtering

{

dst[1] = src[1];

lastKnownGoodValue = src[1];

} else

{

dst[1] = lastKnownGoodValue;

}

dst[2] = src[2]; // passing

}



void WriteConvertFcn(const double* src, double* dst) {

    // We assume that src is a 2 element double array, which has:

    // src[0] = motor power in the range [-1, 1] (scaling)

    // -> We want the output in the range [0, 255]

    // src[1] = some measurement with unreliable communication; once

    // in a while a (faulty) 0 is received; this should be

    // filtered and the previous value should be passed (filtering)



    static double lastKnownGoodValue = 0;



    // Scale the motor power to the range [0, 255]

    double motorPowerScaled = (src[0] + 1) / 2 * 255;



    // Filter the measurement with unreliable communication

    if (src[1] != 0) {

        dst[1] = src[1];

        lastKnownGoodValue = src[1];

    } else {

        dst[1] = lastKnownGoodValue;

    }



    // Store the scaled motor power and the filtered measurement

    dst[0] = motorPowerScaled;

    dst[1] = lastKnownGoodValue;

}



int main()

{

    //CREATE CNTRL-C HANDLER

    signal(SIGINT, exit_handler);



    printf("Press Ctrl-C to stop program\n"); // Note: this will 

        // not kill the program; just jump out of the wait loop. Hence,

        // you can still do proper clean-up. You are free to alter the

        // way of determining when to stop (e.g., run for a fixed time).





   

    



    int sendParameters[8] = {0, -1, 1, -1, 2, -1, 3, -1};

    int receiveParameters[12] = {0, -1, -1, -1, -1, -1, 1, -1, -1, -1, -1, -1};



    IcoComm *icoComm = new IcoComm(sendParameters, receiveParameters);

    icoComm->setVerbose (true);

    //icoComm->setReadConvertFcn()

    // IDDPComm *iddpComm = new IDDPComm(NULL, NULL, NULL, receiveParameters);

    //XSSPComm *

    frameworkComm *controller_uPorts[] = {

        icoComm};

    

    frameworkComm *controller_yPorts[] = {

        icoComm};

    

    ControllerPan *controller_class = new ControllerPan;

    runnable *controller_runnable = new wrapper<ControllerPan>(

        controller_class, controller_uPorts, controller_yPorts, 1, 1

    );

    controller_runnable->setSize(12,8);



    xenoThread controllerThread(controller_runnable);

    controllerThread.init(1000000, 80 , 1);

    controllerThread.start("Controller");







    // WAIT FOR CNTRL-C

    timespec t = {.tv_sec=0, .tv_nsec=100000000}; // 1/10 second



    while (!exitbool)

    {

        // Let the threads do the real work

        nanosleep(&t, NULL);

        // Wait for Ctrl-C to exit

    }

    printf("Ctrl-C was pressed: Stopping gracefully...\n");

    controllerThread.stopThread();

    

    //CLEANUP HERE





    return 0;

}