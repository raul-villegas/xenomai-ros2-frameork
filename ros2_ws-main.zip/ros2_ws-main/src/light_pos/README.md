# light_pos

A non-open-CV implementation of the light_pos node of assignment 1.1.4. Can be used as a replacement for your own node on the Raspberry Pi if you have used Open CV (because OpenCV does not run on the installation of the Raspberry Pi).

Usage: unzip both `light_pos` and `asdfr_interfaces` into your ros2 workspace and compile with `colcon build`.