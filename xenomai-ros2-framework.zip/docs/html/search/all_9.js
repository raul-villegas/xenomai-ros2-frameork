var searchData=
[
  ['wrapper_34',['wrapper',['../classwrapper.html',1,'wrapper&lt; T &gt;'],['../classwrapper.html#a5e23cac53139dceb9ec2cb05c02faf15',1,'wrapper::wrapper()']]]
];
